<div class="span12">
    <div class="widget ">
        <div class="widget-header">
            <i class="icon-list-ul"></i>
            <h3>Email & SMS Management</h3>
        </div>
        <div class="widget-content">
            <div class="tabbable">
                <ul class="nav nav-tabs">
                    <li <?php if($rasel == 1) echo "class='active'";?>>
                        <a href="../email_and_sms_management/email">Email</a>
                    </li>
                    <li <?php if($rasel == 2) echo "class='active'";?>>
                        <a href="../email_and_sms_management/sms">SMS</a>
                    </li>
                    <li <?php if($rasel == 3) echo "class='active'";?>>
                        <a href="../email_and_sms_management/classwisemessage">Message</a>
                    </li>
                </ul>