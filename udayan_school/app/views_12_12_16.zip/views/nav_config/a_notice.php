<div class="span12">
    <div class="widget ">
        <div class="widget-header">
            <i class="icon-list-ul"></i>
            <h3>Notice</h3>
        </div>
        <div class="widget-content">
            <div class="tabbable">
                <ul class="nav nav-tabs">
                    <li <?php if($rasel == 1) echo "class='active'";?>>
                        <a href="../notice_management/add_notice">Add Notice</a>
                    </li>
                    <li <?php if($rasel == 2) echo "class='active'";?>>
                        <a href="../notice_management/show_notice">Show Notice</a>
                    </li>
                </ul>