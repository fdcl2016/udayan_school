<div class="span12">
    <div class="widget ">
        <div class="widget-header">
            <i class="icon-list-ul"></i>
            <h3>Reports</h3>
        </div>
        <div class="widget-content">
            <div class="tabbable">
                <ul class="nav nav-tabs">
                    <li <?php if($rasel == 1) echo "class='active'";?>>
                        <a href="../reports/report">Students Report</a>
                    </li>
                    <li <?php if($rasel == 2) echo "class='active'";?>>
                        <a href="../reports/allstudenst">All Students Report</a>
                    </li>
                </ul>