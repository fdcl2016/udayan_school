@extends('master.master')
@section('header')
@stop
@section('content')
    <div class="span12">

        <div class="widget ">

            <div class="widget-header">
                <i class="icon-list-ul"></i>

            </div>
            <div class="widget-content">
                <div class="tabbable">

                    <div class="tab-content">
                        <br/>
                        <div class="fdcl_content_profile">
                            <div class="widget-header"></div>
                            <div class="widget-content">
                                <div class="table-responsive" style="padding-left:3%;padding-right:3%">

                                    <h2 style="text-align: center; font-weight: bold; color: green"> BOOK LIST WILL BE UPLOADED SOON .... STAY CONNECTED </h2>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    </div>
    <!-- /widget-content -->

    </div>
    <!-- /widget -->

    </div> <!-- /span8 -->

@stop
@section('content_footer')
@stop