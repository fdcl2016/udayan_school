<div class="span12">
    <div class="widget ">
        <div class="widget-header">
            <i class="icon-list-ul"></i>
            <h3>Subject Management</h3>
        </div>
        <div class="widget-content">
            <div class="tabbable">
                <ul class="nav nav-tabs">
                    <li <?php if($rasel == 1) echo "class='active'";?>>
                        <a href="../subject_management/create_subject">Create Subject</a>
                    </li>
                    <li <?php if($rasel == 2) echo "class='active'";?>>
                        <a href="../subject_management/edit_subject">Edit Subject</a>
                    </li>
                    <li <?php if($rasel == 3) echo "class='active'";?>>
                        <a href="../subject_management/assign_subject_to_teacher">Assign Subject To Teacher</a>
                    </li>
                    <li <?php if($rasel == 4) echo "class='active'";?>>
                        <a href="../subject_management/classwise_subject">Classwise Subject</a>
                    </li>
                    <li <?php if($rasel == 5) echo "class='active'";?>>
                        <a href="../subject_management/classwise_subject_list">Classwise Subject List</a>
                    </li>
                    <li <?php if($rasel == 6) echo "class='active'";?>>
                        <a href="../result_management/configure_result">Configure Result</a>
                    </li>
                    <li <?php if($rasel == 7) echo "class='active'";?>>
                        <a href="../result_management/list_of_config">List of Configuration</a>
                    </li>
                      
                      <li <?php if($rasel == 8) echo "class='active'";?>>
                        <a href="../subject_management/fourth_subject">Fourth Subject</a>
                    </li>
             
            
                </ul>